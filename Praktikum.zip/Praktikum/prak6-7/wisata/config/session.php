<?php

return [
    'driver' => 'file', // Pilihan: file, cookie, database, dll.
    'lifetime' => 120, // Waktu hidup session dalam menit
    'expire_on_close' => false,
    'encrypt' => false,
    'files' => storage_path('framework/sessions'),
    'cookie' => 'lumen_session',
    'path' => '/',
    'domain' => null,
    'secure' => false,
    'http_only' => true,
];
