<?php
$requestMethod = $_SERVER["REQUEST_METHOD"];
include('api/Rest.php');
$api = new Rest();
switch($requestMethod){
    case 'GET':
        $wstID = isset($_GET['id']) ? $_GET['id'] : '';
        $api->getWisata($wstID);
        break;
    default:
        header("HTTP/1.0 405 Method Not Allowed");
    break;
}