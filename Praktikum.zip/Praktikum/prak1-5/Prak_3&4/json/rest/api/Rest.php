<?php
class Rest {
    private $host = 'localhost';
    private $user = 'root';
    private $pass = '';
    private $db = 'json';
    private $wstTable = 'wisata';
    private $dbConnect = false;

    public function __construct() {
        $this->dbConnect = new mysqli($this->host, $this->user, $this->pass, $this->db);
        if ($this->dbConnect->connect_error) {
            die("Connection failed: " . $this->dbConnect->connect_error);
        }
    }

    private function executeQuery($query) {
        $result = $this->dbConnect->query($query);
        if (!$result) {
            die("Query execution failed: " . $this->dbConnect->error);
        }
        return $result;
    }

    public function getWisata($wstID = null) {
        $sqlQuery = ($wstID) ? " WHERE id_wisata = '$wstID'" : '';
        $wstQuery = "SELECT id_wisata, kota, landmark, tarif FROM $this->wstTable $sqlQuery ORDER BY id_wisata ASC";
        
        $resultQuery = $this->executeQuery($wstQuery);
        $wstData = $resultQuery->fetch_all(MYSQLI_ASSOC);
        
        header('Content-Type: application/json');
        echo json_encode($wstData);
    }

    public function insertWisata($wstData) {
        $kota = $wstData['kota'];
        $landmark = $wstData['landmark'];
        $tarif = $wstData['tarif'];

        $wstQuery = "INSERT INTO $this->wstTable (kota, landmark, tarif) VALUES ('$kota', '$landmark', '$tarif')";
        $this->executeQuery($wstQuery);

        $wstResponse = [
            'status' => ($this->dbConnect->affected_rows > 0) ? 1 : 0,
            'status_message' => ($this->dbConnect->affected_rows > 0) ? 'Wisata sukses dibuat' : 'Wisata gagal dibuat'
        ];
        header('Content-Type: application/json');
        echo json_encode($wstResponse);
    }

    public function updateWisata($wstData) {
        $kota = $wstData['kota'];
        $landmark = $wstData['landmark'];
        $tarif = $wstData['tarif'];
        $wstID = $wstData['id'];

        $wstQuery = "UPDATE $this->wstTable SET kota = '$kota', landmark = '$landmark', tarif = '$tarif' WHERE id_wisata = '$wstID'";
        $this->executeQuery($wstQuery);

        $wstResponse = [
            'status' => ($this->dbConnect->affected_rows > 0) ? 1 : 0,
            'status_message' => ($this->dbConnect->affected_rows > 0) ? 'Wisata sukses diupdate' : 'Wisata gagal diupdate'
        ];
        header('Content-Type: application/json');
        echo json_encode($wstResponse);
    }

    public function deleteWisata($wstID) {
        $wstQuery = "DELETE FROM $this->wstTable WHERE id_wisata = '$wstID'";
        $this->executeQuery($wstQuery);

        $wstResponse = [
            'status' => ($this->dbConnect->affected_rows > 0) ? 1 : 0,
            'status_message' => ($this->dbConnect->affected_rows > 0) ? 'Wisata berhasil dihapus' : 'Wisata gagal dihapus'
        ];
        header('Content-Type: application/json');
        echo json_encode($wstResponse);
    }
}
?>
