<?php 
$age = [
    "agus" => 32,
    "budi" => 18,
    "cici" => 40,
    "bagus" => 21
];

echo json_encode($age);

$encode_age = '{
    "Agus" : 22,
    "Budi" : 19,
    "Cici" : 56
}';

$result_age = json_decode($encode_age);
echo "\n  $result_age->Agus \n  $result_age->Budi \n  $result_age->Cici";
?>